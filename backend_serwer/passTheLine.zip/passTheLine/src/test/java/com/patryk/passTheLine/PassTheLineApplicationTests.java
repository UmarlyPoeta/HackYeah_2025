package com.patryk.passTheLine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PassTheLineApplicationTests {

	@Test
	void contextLoads() {
	}

}
